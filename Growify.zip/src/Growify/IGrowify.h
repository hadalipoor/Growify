#ifndef IGROWIFY
#define IGROWIFY

class IGrowify {
public:
    virtual void update() = 0;
    virtual void initialize() = 0;
};

#endif // IGROWIFY
