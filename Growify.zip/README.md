Growify is a smart multi scenario backend application for ESP32 arduino using OStad Framework.
https://github.com/hadalipoor/OStad